package pojo;

public class DespositType {

	private String typename;

	public String getTypename() {
		return typename;
	}

	public void setTypename(String typename) {
		this.typename = typename;
	}
	
	public String toString(){
		return this.typename;
	}
	
}
